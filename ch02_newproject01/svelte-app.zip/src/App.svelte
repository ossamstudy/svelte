<script>
	let name = 'ossam';
</script>

<h1>Hello {name}!</h1>
